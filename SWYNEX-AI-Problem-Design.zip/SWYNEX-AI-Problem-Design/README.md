# SWYNEX AI Problem Design

## AI-Based Customer Support Query Classifier

### 1. Problem Statement

Customer support teams receive a large number of customer queries every day. Manually categorizing these queries into different support categories can be time-consuming.

This project develops a machine-learning classifier that automatically identifies the intent of a customer query and assigns it to a predefined category.

### 2. Objective

The system classifies customer queries into five categories:

- Account
- Payment
- Order Tracking
- Cancellation
- Refund

### 3. Target Users

- Customer support teams
- Help-desk operators
- E-commerce companies
- Support automation systems

### 4. Data Source

A small synthetic labeled dataset was created specifically for this proof-of-concept project. It contains example customer support queries representing five common intents.

### 5. AI Approach

The project uses Natural Language Processing with:

- TF-IDF text vectorization
- Logistic Regression classification
- Scikit-learn

### 6. Workflow

```text
Customer Query
      |
      v
Text Input
      |
      v
TF-IDF Vectorization
      |
      v
Logistic Regression
      |
      v
Predicted Customer Intent
```

### 7. Evaluation

The model is evaluated using:

- Accuracy
- Precision
- Recall
- F1-score

Run the training script to generate the actual evaluation results for the current dataset.

### 8. Success Criteria

The proof-of-concept target is approximately 80% or higher accuracy on the held-out test set, while maintaining reasonable precision, recall, and F1-score across the five categories.

The reported result should be taken from the actual program output rather than manually estimated.

### 9. Constraints

- Small dataset
- Five predefined categories
- No conversation history
- Limited training examples
- Proof-of-concept only
- Not intended as a production customer-support system

### 10. Example Predictions

| Input | Expected Category |
|---|---|
| Where is my package? | Order Tracking |
| I forgot my password | Account |
| My card payment failed | Payment |
| I want to cancel my order | Cancellation |
| I need my money back | Refund |

### 11. Installation

Install Python 3.10+ and run:

```bash
pip install -r requirements.txt
```

### 12. Train and Evaluate

From the repository root:

```bash
python src/train_model.py
```

The script prints accuracy, precision, recall and F1-score and saves the trained model to:

```text
model/customer_query_model.pkl
```

### 13. Run the Demo

```bash
python demo.py
```

Example:

```text
Enter customer query (or type 'exit'): Where is my package?

Predicted Category: Order Tracking
```

### 14. Future Improvements

- Use a larger real-world dataset
- Add confidence scores
- Test transformer-based NLP models
- Add a web interface
- Add multilingual support
- Integrate with customer-support software
- Add human review for low-confidence predictions

### 15. Project Structure

```text
SWYNEX-AI-Problem-Design/
|
|-- README.md
|-- requirements.txt
|-- .gitignore
|-- demo.py
|
|-- data/
|   `-- customer_queries.csv
|
|-- src/
|   `-- train_model.py
|
`-- model/
    `-- .gitkeep
```
