import joblib

MODEL_PATH = "model/customer_query_model.pkl"


def main():
    try:
        model = joblib.load(MODEL_PATH)
    except FileNotFoundError:
        print("Model not found.")
        print("Run this first: python src/train_model.py")
        return

    print("=" * 45)
    print(" AI CUSTOMER SUPPORT QUERY CLASSIFIER")
    print("=" * 45)
    print("\nCategories:")
    print("Account")
    print("Payment")
    print("Order Tracking")
    print("Cancellation")
    print("Refund")

    while True:
        query = input("\nEnter customer query (or type 'exit'): ")

        if query.lower().strip() == "exit":
            print("Goodbye!")
            break

        if not query.strip():
            print("Please enter a customer query.")
            continue

        prediction = model.predict([query])[0]
        print("\nPredicted Category:", prediction)


if __name__ == "__main__":
    main()
