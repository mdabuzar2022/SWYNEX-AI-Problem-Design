import pandas as pd
import joblib

from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, classification_report


DATA_PATH = "data/customer_queries.csv"
MODEL_PATH = "model/customer_query_model.pkl"


def main():
    data = pd.read_csv(DATA_PATH)

    X = data["text"]
    y = data["label"]

    X_train, X_test, y_train, y_test = train_test_split(
        X,
        y,
        test_size=0.2,
        random_state=42,
        stratify=y
    )

    model = Pipeline([
        ("tfidf", TfidfVectorizer()),
        ("classifier", LogisticRegression(max_iter=1000))
    ])

    model.fit(X_train, y_train)

    predictions = model.predict(X_test)
    accuracy = accuracy_score(y_test, predictions)

    print("=" * 45)
    print("AI MODEL EVALUATION")
    print("=" * 45)
    print(f"\nAccuracy: {accuracy:.2%}\n")
    print("Classification Report:")
    print(classification_report(y_test, predictions))

    joblib.dump(model, MODEL_PATH)
    print(f"\nModel saved successfully: {MODEL_PATH}")


if __name__ == "__main__":
    main()
